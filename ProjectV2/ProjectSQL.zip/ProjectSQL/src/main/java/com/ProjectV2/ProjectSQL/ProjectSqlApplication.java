package com.ProjectV2.ProjectSQL;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectSqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectSqlApplication.class, args);
	}
}
