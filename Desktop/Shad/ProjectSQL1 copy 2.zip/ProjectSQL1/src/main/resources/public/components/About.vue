<template>
    <div class="about">
        <h1>This is abot page</h1>
        <p>ajsdnasdasdnaksdnaksda</p>
    </div>
</template>