package snippet;

public class Snippet {
	sudo lsof -PiTCP -sTCP:LISTEN
}

